package com.example.mv_medic;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class Myorder extends AppCompatActivity {
    private RecyclerView datalist;
    private DatabaseReference mdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        datalist=(RecyclerView)findViewById(R.id.myrecyclerview);
        datalist.setHasFixedSize(true);
        datalist.setLayoutManager(new LinearLayoutManager(this));
        mdata= FirebaseDatabase.getInstance().getReference().child("Myorders").child("1132");
        mdata.keepSynced(true);


    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<data,dataViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<data, dataViewHolder>
                (data.class,R.layout.data_row,dataViewHolder.class,mdata) {
            @Override
            protected void populateViewHolder(dataViewHolder viewHolder, data mo, int i) {
                viewHolder.setName(mo.getName());
                viewHolder.setInvoiceno(mo.getInvoiceno());
                viewHolder.setPrice(mo.getPrice());
                viewHolder.setDate(mo.getDate());
                viewHolder.setImgurl(getApplicationContext(),mo.getImgurl());
            }
        };
        datalist.setAdapter(firebaseRecyclerAdapter);
    }
    public static class dataViewHolder extends RecyclerView.ViewHolder
    {
        View view;
        public dataViewHolder(@NonNull View itemView) {
            super(itemView);
            view=itemView;
        }
        public void setName(String name2){
            TextView name1=(TextView)view.findViewById(R.id.name);
            name1.setText(name2);
        }
        public void setInvoiceno(String invoiceno1){
            TextView inv=(TextView)view.findViewById(R.id.invno);
            inv.setText(invoiceno1);
        }
        public void setPrice(String price1){
            TextView pr=(TextView)view.findViewById(R.id.price);
            pr.setText(price1);
        }
        public void setDate(String date1){
            TextView da=(TextView)view.findViewById(R.id.date);
            da.setText(date1);
        }
        public void setImgurl(Context ctx,String img1){

            ImageView im=(ImageView) view.findViewById(R.id.img);
            Picasso.get().load(img1).resize(50,50).centerCrop().into(im);
        }

    }
}
