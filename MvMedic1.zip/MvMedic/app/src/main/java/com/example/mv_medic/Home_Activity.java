package com.example.mv_medic;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.mv_medic.fragments.Accountfragment;
import com.example.mv_medic.fragments.Articlefragment;
import com.example.mv_medic.fragments.Dashboardfragment;
import com.example.mv_medic.fragments.Homefragment;
import com.example.mv_medic.login.LoginClassifierActivity;
import com.example.mv_medic.notificaion.NotificationFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Home_Activity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_);
        BottomNavigationView navView = findViewById(R.id.nav_view);

        navView.setOnNavigationItemSelectedListener(this);
        LoadFragment(new Homefragment());

    }
    private boolean LoadFragment(Fragment fragment){
        if(fragment!=null){
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frameLayout,fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment=null;
        switch (menuItem.getItemId()){
            case R.id.navigation_home:
                fragment=new Homefragment();
                break;

            case R.id.navigation_reminder:
                fragment=new Dashboardfragment();
                break;
            case R.id. navigation_notifications:
                fragment= new NotificationFragment();
                break;
            case R.id.navigation_article:
                fragment=new Articlefragment();
                break;
            case  R.id.actionsearch:



            case R.id.navigation_account:
                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                if (currentUser==null){
                    Toast.makeText(Home_Activity.this,"Login to continue",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(Home_Activity.this, LoginClassifierActivity.class);
                    startActivity(intent);
                }
                else{

                    fragment=new Accountfragment();

                }

                break;

        }
        return LoadFragment(fragment);
    }
}
