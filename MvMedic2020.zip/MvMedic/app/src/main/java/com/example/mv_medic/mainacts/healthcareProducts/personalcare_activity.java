package com.example.mv_medic.mainacts.healthcareProducts;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.mv_medic.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class personalcare_activity extends AppCompatActivity {
    private RecyclerView mBloglist;
    private DatabaseReference mDatabase;
    private RecyclerView.LayoutManager layoutManager;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personalcare_activity);
        mBloglist =(RecyclerView)findViewById(R.id.myrecycle);
        mBloglist.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        mBloglist.setLayoutManager(layoutManager);
        mBloglist.setItemAnimator(new DefaultItemAnimator());

        mDatabase = FirebaseDatabase.getInstance().getReference().child("products1").child("Personal Care");
        mDatabase.keepSynced(true);


    }
    public void onStart(){
        super.onStart();
      //  FirebaseRecyclerAdapter<Blog,BlogViewHolder>firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Blog,BlogViewHolder>(Blog.class,R.layout.blog_row,B.class,mDatabase){

        FirebaseRecyclerAdapter<Blog,BlogViewHolder>firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Blog, BlogViewHolder>(Blog.class,R.layout.blog_row,BlogViewHolder.class,mDatabase) {
            @Override
            protected void populateViewHolder(BlogViewHolder viewHolder, Blog model, int postion) {
                viewHolder.setname(model.getName());
                viewHolder.setprice(model.getPrice());
                viewHolder.setImage(getApplicationContext(),model.getImage());

            }
        };
        mBloglist.setAdapter(firebaseRecyclerAdapter);
    }

    public static class BlogViewHolder extends RecyclerView.ViewHolder{


        View mview;
        public BlogViewHolder(View itemview)
        {
            super(itemview);
            mview=itemview;


        }

        public void setname(String name)
        {
            TextView postname=(TextView)mview.findViewById(R.id.name1);
            postname.setText(name);
        }
        public void setprice(String price)
        {
            TextView postprice=(TextView)mview.findViewById(R.id.price1);
            postprice.setText(price);

        }
        public void setImage(Context ctx,String image)
        {
            ImageView postimage=(ImageView)mview.findViewById(R.id.postimage);
            Picasso.get().load(image).into(postimage);
        }


    }
}
