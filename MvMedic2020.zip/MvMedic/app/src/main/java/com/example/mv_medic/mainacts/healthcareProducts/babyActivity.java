package com.example.mv_medic.mainacts.healthcareProducts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mv_medic.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class babyActivity extends AppCompatActivity {
    private RecyclerView mBloglist;
    private DatabaseReference mDatabase;




    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baby);
        mBloglist =(RecyclerView)findViewById(R.id.myrecycle);
        mBloglist.setHasFixedSize(true);
        mBloglist.setLayoutManager(new LinearLayoutManager(this));
       // mBloglist.setItemAnimator(new DefaultItemAnimator());

        mDatabase = FirebaseDatabase.getInstance().getReference().child("products1").child("Baby");
        mDatabase.keepSynced(true);


    }
    public void onStart(){
        super.onStart();
        //  FirebaseRecyclerAdapter<Blog,BlogViewHolder>firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Blog,BlogViewHolder>(Blog.class,R.layout.blog_row,B.class,mDatabase){

            FirebaseRecyclerAdapter<Blog, BlogViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Blog,BlogViewHolder>(Blog.class,R.layout.blog_row,BlogViewHolder.class,mDatabase) {
            @Override
            protected void populateViewHolder(BlogViewHolder viewHolder, Blog model, int postion) {
                viewHolder.setname(model.getName());
                viewHolder.setprice(model.getPrice());
                viewHolder.setImage(getApplicationContext(),model.getImage());

            }
        };
        mBloglist.setAdapter(firebaseRecyclerAdapter);
    }

    public static class BlogViewHolder extends RecyclerView.ViewHolder{


        View mview;
        public BlogViewHolder(View itemview)
        {
            super(itemview);
            mview=itemview;


        }

        public void setname(String name)
        {
            TextView postname=(TextView)mview.findViewById(R.id.name1);
            postname.setText(name);
        }
        public void setprice(String price)
        {
            TextView postprice=(TextView)mview.findViewById(R.id.price1);
            postprice.setText(price);

        }
        public void setImage(Context ctx, String image)
        {
            ImageView postimage=(ImageView)mview.findViewById(R.id.postimage);
            Picasso.get().load(image).resize(50,50).centerCrop().into(postimage);
        }


    }
}
