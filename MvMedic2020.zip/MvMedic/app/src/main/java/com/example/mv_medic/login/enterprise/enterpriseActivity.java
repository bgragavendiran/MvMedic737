package com.example.mv_medic.login.enterprise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mv_medic.R;

public class enterpriseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enterprise);
    }
}
