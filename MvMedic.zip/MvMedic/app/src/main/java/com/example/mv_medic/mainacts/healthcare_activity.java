package com.example.mv_medic.mainacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.example.mv_medic.R;
import com.example.mv_medic.mainacts.healthcareProducts.NutritionActivity;
import com.example.mv_medic.mainacts.healthcareProducts.babyActivity;
import com.example.mv_medic.mainacts.healthcareProducts.personalcare_activity;
import com.example.mv_medic.mainacts.healthcareProducts.sexual_activity;

public class healthcare_activity extends AppCompatActivity {
    ViewFlipper viewFlipper;
    int[] imageos={R.drawable.banner_1,R.drawable.banner_2};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_healthcare_activity);
        viewFlipper=(ViewFlipper)findViewById(R.id.fliper);
        for(int i=0;i<imageos.length;i++){
            flip_image(imageos[i]);
        }
    }

    private void flip_image(int i) {
        ImageView view=new ImageView(this);
        view.setBackgroundResource(i);
        viewFlipper.addView(view);
        viewFlipper.setFlipInterval(4000);
        viewFlipper.setAutoStart(true);
        viewFlipper.setInAnimation(this,android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(this,android.R.anim.slide_out_right);
    }

    public void personal_care(View view) {
        Intent i=new Intent(healthcare_activity.this, personalcare_activity.class);
        startActivity(i);
    }

    public void nutrition(View view) {
        Intent i=new Intent(healthcare_activity.this, NutritionActivity.class);
        startActivity(i);
    }

    public void sexual_welness(View view) {
        Intent i=new Intent(healthcare_activity.this, sexual_activity.class);
        startActivity(i);
    }

    public void devices(View view) {
    }

    public void mother_care(View view) {
        Intent i=new Intent(healthcare_activity.this, babyActivity.class);
        startActivity(i);
    }
}
