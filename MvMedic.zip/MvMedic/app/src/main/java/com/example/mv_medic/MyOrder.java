package com.example.mv_medic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MyOrder extends AppCompatActivity {
    RecyclerView recyclerview;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);

        recyclerview = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerview.setHasFixedSize(true);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Myorders");
        databaseReference.keepSynced(true);



    }
    public void onStart(){
        super.onStart();
        //  FirebaseRecyclerAdapter<Blog,BlogViewHolder>firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Blog,BlogViewHolder>(Blog.class,R.layout.blog_row,B.class,mDatabase){

        FirebaseRecyclerAdapter<order,BlogViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<order, BlogViewHolder>(order.class,R.layout.element,BlogViewHolder.class,databaseReference) {
            @Override
            protected void populateViewHolder(BlogViewHolder viewHolder, order model, int postion) {
                viewHolder.setid(model.getId());
                viewHolder.setprice(model.getPrice());
                viewHolder.setdate(model.getDate());
                viewHolder.settime(model.getTime());

            }
        };
        recyclerview.setAdapter(firebaseRecyclerAdapter);
    }
    public static class BlogViewHolder extends RecyclerView.ViewHolder{


        View mview;
        public BlogViewHolder(View itemview)
        {
            super(itemview);
            mview=itemview;


        }

        public void setid(String id)
        {
            TextView idset=(TextView)mview.findViewById(R.id.moniid);
            idset.setText(id);
        }
        public void setprice(String price)
        {
            TextView orderprice=(TextView)mview.findViewById(R.id.moniprice);
            orderprice.setText(price);

        }
        public void setdate(String date)
        {
            TextView orderdate=(TextView)mview.findViewById(R.id.monidate);
            orderdate.setText(date);

        }
        public void settime(String time)
        {
            TextView ordertime=(TextView)mview.findViewById(R.id.monitime);
            ordertime.setText(time);

        }


    }
}
